
def run_perceptron(weights, data, labels, learning_rate=1):
    epoch_error = 0
    # Para cada instancia e label
    for x, y in zip(data, labels):
	# IMPLEMENTE AQUI A ATUALIZACAO DOS PESOS
        pass

    return weights, epoch_error

