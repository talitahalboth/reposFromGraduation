Author: Augusto Lopez Dantas
Email: aldantas@protonmail.com


Requirements:
    pip3 install -r requirements.txt

    You must have GTK3+ libs installed, also, make sure you have
    the GObject python bindings.

    Ubuntu:
        (probably installed by default)
        # apt install python3-gi

    Arch Linux:
        # pacman -S gtk3 python-gobject

Usage:
    python3 app_perceptron.py
